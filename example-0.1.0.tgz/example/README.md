Example helm chart readme.
